# Cone-Rolling-Tool

Mechanische Hilfe zum Formen **leerer Papier-Cones**. Die Umsetzung erfolgt in
**OpenSCAD**. Der Stand umfasst eine Konzeptstudie und ein parametrisches
P0-Modell mit Formdorn und offener Anlegestation. Physische Funktionstests stehen
noch aus.

- [OpenSCAD-Datei](cad/ConeRolling_P0.scad)
- [Öffnen, Parameter ändern und STL exportieren](cad/README_OPENSCAD.md)
- [STL-Dateien für beide Formatvorgaben](cad/exports)
- [Konzeptstudie und Prototypplan](docs/konzeptstudie.md)
- [Abwicklungsstudie, A4 quer, Maßstab 1:1](docs/abwicklung.svg)

Die Papierformate und Materialwerte sind ausdrücklich Annahmen. Die
Geometrieberechnung benötigt nur Python 3.10 oder neuer, keine Zusatzpakete:

```sh
python3 tools/cone_geometry.py
python3 tools/cone_geometry.py --svg docs/abwicklung.svg
```

Die Rechnung prüft die ideale Papierabdeckung. Sie simuliert weder den
Wickelvorgang noch Reibung, Klebung oder reales Materialverhalten.
